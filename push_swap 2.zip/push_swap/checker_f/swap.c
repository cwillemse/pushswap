#include "push_swap.h"

void	sa(t_push_swap *stacks)
{
	if (stacks->a->next == NULL)
		return ;
	t_swap	*tmp;
	t_swap	*tmp2;

	tmp = stacks->a;
	tmp2 = stacks->a->next;
	tmp->next = (stacks->a->next->next != 0) ? stacks->a->next->next : 0;
	tmp2->next = tmp;
	stacks->a = tmp2;
}

void	sb(t_push_swap *stacks)
{
	if (stacks->b->next == NULL)
		return ;
	t_swap     *tmp;
	t_swap     *tmp2;

	tmp = stacks->b;
	tmp2 = stacks->b->next;
	tmp->next =  (stacks->b->next->next != 0) ? stacks->b->next->next : 0;
	tmp2->next = tmp;
	stacks->b = tmp2;
}

void	ss(t_push_swap *stacks)
{
	sa(stacks);
	sb(stacks);
}
