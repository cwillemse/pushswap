/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   free2.c                                            :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: cwillems <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2018/09/27 11:58:55 by cwillems          #+#    #+#             */
/*   Updated: 2018/09/27 11:58:57 by cwillems         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "push_swap.h"

void	free2(char	***all)
{
	char	**tmp;
	int		counter;

	counter = -1;
	tmp = *all;
	while (tmp[++counter])
		free(tmp[counter]);
	free(tmp);
}